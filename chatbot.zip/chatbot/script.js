document.addEventListener('DOMContentLoaded', function() {
  // DOM Elements
  const chatBody = document.querySelector(".chat-body");
  const chatForm = document.querySelector("#chat-form");
  const messageInput = document.querySelector("#message-input");

  // Enhanced Configuration
  const CONFIG = {
    // Free API endpoint (no key needed)
    apiUrl: "https://api-inference.huggingface.co/models/google/gemma-7b-it",
    thinkingDelay: 500, // More natural delay
    errorMessage: "I'm having temporary connection issues. Here's what I know:"
  };

  // Improved Knowledge Base
const KNOWLEDGE_BASE = {
  countries: {
    "sri lanka": {
      capital: "Sri Jayawardenepura Kotte (administrative) and Colombo (commercial)",
      population: "21.7 million (2023)",
      currency: "Sri Lankan Rupee (LKR)",
      language: "Sinhala & Tamil",
      facts: [
        "Island nation in South Asia",
        "Famous for Ceylon tea",
        "Rich Buddhist heritage",
        "Known for wildlife and beaches"
      ]
    },
        "india": {
      capital: "New Delhi",
      population: "1.428 billion",
      currency: "Indian Rupee (₹)",
      language: "Hindi, English (official), and 21 other recognized languages",
      facts: [
      "World's largest democracy",
      "Birthplace of yoga and Ayurveda",
      "Home to the Taj Mahal",
      "Major hub for IT and software services"
      ]
    },
    "japan": {
      capital: "Tokyo",
      population: "125.7 million",
      currency: "Japanese Yen (¥)",
      language: "Japanese",
      facts: [
        "Land of the Rising Sun",
        "Leader in robotics & technology",
        "Traditional arts like tea ceremony",
        "Famous for sushi & anime"
      ]
    }
    
  },
  
  universities: {
    "wayamba university": {
      location: "Kuliyapitiya, Sri Lanka",
      faculties: [
        "Faculty of Applied Sciences",
        "Faculty of Agriculture and Plantation Management",
        "Faculty of Business Studies and Finance",
        "Faculty of Livestock, Fisheries and Nutrition"
      ],
      established: "1999",
      website: "https://www.wyb.ac.lk"
    }
  }, // <-- Added comma here
  


  greetings: [
    "Hello! 👋 How can I assist you today?",
    "Hi there! 😊 Need help with something?",
    "Hey! 🙌 What would you like to ask?"
  ],
  // Added IT topics with brief descriptions
  it_topics: {
    "ai": "Artificial Intelligence is the simulation of human intelligence in machines that can learn, reason, and solve problems.",
    "ml": "Machine Learning is a subset of AI that enables systems to learn patterns from data and make predictions.",
    "html": "HTML (HyperText Markup Language) is the standard language used to create webpages.",
    "css": "CSS (Cascading Style Sheets) is used to style and layout web pages."
  },

  fallback: "I'm still learning 🌱. Please try rephrasing your question or ask about countries, universities, or IT topics!"
};


  // Create message element (optimized)
  function createMessage(content, type = 'bot') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}-message`;
    
    const avatar = type === 'bot' ? `
      <svg class="bot-avatar" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">
        <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 128c52.9 0 96 43.1 96 96s-43.1 96-96 96-96-43.1-96-96 43.1-96 96-96zm0 640c-88.4 0-166.4-45.4-213-114.7 1-71.2 142-110.3 213-110.3 71 0 212 39.1 213 110.3C678.4 786.6 600.4 832 512 832z"/>
      </svg>` : '';

    messageDiv.innerHTML = `
      ${avatar}
      <div class="message-content">${content}</div>
    `;
    
    return messageDiv;
  }

  // Enhanced thinking indicator
  function showThinking() {
    const thinkingDiv = document.createElement('div');
    thinkingDiv.className = 'message bot-message thinking';
    thinkingDiv.innerHTML = `
      <svg class="bot-avatar" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">
        <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 128c52.9 0 96 43.1 96 96s-43.1 96-96 96-96-43.1-96-96 43.1-96 96-96zm0 640c-88.4 0-166.4-45.4-213-114.7 1-71.2 142-110.3 213-110.3 71 0 212 39.1 213 110.3C678.4 786.6 600.4 832 512 832z"/>
      </svg>
      <div class="message-content">
        <div class="thinking-indicator">
          <span>.</span><span>.</span><span>.</span>
        </div>
      </div>
    `;
    chatBody.appendChild(thinkingDiv);
    scrollToBottom();
    return thinkingDiv;
  }

  // Scroll to bottom (optimized)
  function scrollToBottom() {
    setTimeout(() => {
      chatBody.scrollTop = chatBody.scrollHeight;
    }, 100);
  }

  // Enhanced response generator
  async function generateResponse(userInput) {
    const lowerInput = userInput.toLowerCase();
    
    // Check greetings
    if (/hello|hi|hey/.test(lowerInput)) {
      return KNOWLEDGE_BASE.greetings[
        Math.floor(Math.random() * KNOWLEDGE_BASE.greetings.length)
      ];
    }
    if (/hello|hi|hey/.test(lowerInput)) {
  return randomItem(KNOWLEDGE_BASE.greetings);
}

// Check Country Info
for (let country in KNOWLEDGE_BASE.countries) {
  if (lowerInput.includes(country)) {
    const c = KNOWLEDGE_BASE.countries[country];
    if (lowerInput.includes("capital")) return `📍 The capital of ${capitalize(country)} is ${c.capital}`;
    if (lowerInput.includes("currency")) return `💱 The currency of ${capitalize(country)} is ${c.currency}`;
    if (lowerInput.includes("language")) return `🗣️ Languages in ${capitalize(country)}: ${c.language}`;
    return `🌍 Facts about ${capitalize(country)}: ${c.facts.join(", ")}`;
  }
}

// Check University Info
for (let uni in KNOWLEDGE_BASE.universities) {
  if (lowerInput.includes(uni)) {
    const u = KNOWLEDGE_BASE.universities[uni];
    return `🏫 ${capitalize(uni)} is located in ${u.location}. It has faculties like ${u.faculties.join(", ")}. Visit: ${u.website}`;
  }
}

// Check IT Topics
for (let topic in KNOWLEDGE_BASE.it_topics) {
  if (lowerInput.includes(topic)) {
    return `💡 ${capitalize(topic)}: ${KNOWLEDGE_BASE.it_topics[topic]}`;
  }
}

    
    try {
      // Try API call
      const response = await fetch(CONFIG.apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ inputs: userInput })
      });
      
      if (!response.ok) throw new Error("API failed");
      
      const data = await response.json();
      return data[0]?.generated_text || "I got your message! Could you rephrase?";
      
    } catch (error) {
      console.log("Using fallback knowledge");
      // Enhanced fallback
      return `${CONFIG.errorMessage} Sri Lanka is famous for: ${
        KNOWLEDGE_BASE["sri lanka"].facts.slice(0,2).join(" and ")
      }.`;
    }
  }

  // Form submission handler (optimized)
  chatForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    const message = messageInput.value.trim();
    if (!message) return;
    
    // Display user message
    chatBody.appendChild(createMessage(message, 'user'));
    messageInput.value = '';
    scrollToBottom();
    
    // Show thinking indicator
    const thinkingElement = showThinking();
    
    // Get and display response
    try {
      const botResponse = await generateResponse(message);
      thinkingElement.remove();
      chatBody.appendChild(createMessage(botResponse));
    } catch (error) {
      thinkingElement.remove();
      chatBody.appendChild(createMessage(CONFIG.errorMessage));
    }
    
    scrollToBottom();
  });

  // Improved textarea handling
  messageInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = `${Math.min(this.scrollHeight, 150)}px`;
  });

  // Close button
  document.querySelector("#close-chatbot")?.addEventListener('click', () => {
    console.log("Chat minimized");
  });
});

// Enhanced knowledge base with Wayamba University details
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}




  const emojiPicker = document.getElementById('emoji-picker');
  const emojiBtn = document.getElementById('emoji-btn');
  const inputField = document.getElementById('user-input');

  // Toggle picker visibility
  emojiBtn.addEventListener('click', () => {
    emojiPicker.style.display = emojiPicker.style.display === 'none' ? 'block' : 'none';
  });

  // Insert selected emoji into input
  emojiPicker.addEventListener('emoji-click', event => {
    inputField.value += event.detail.unicode;
    inputField.focus();
    emojiPicker.style.display = 'none';
  });

